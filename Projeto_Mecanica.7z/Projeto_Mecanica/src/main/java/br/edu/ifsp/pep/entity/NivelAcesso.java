

package br.edu.ifsp.pep.entity;


public enum NivelAcesso {

    Publico, Financeiro, Comum, Administrador;
}
