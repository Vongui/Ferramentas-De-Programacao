package br.edu.ifsp.pep.entity;

/**
 *
 * @author aluno
 */
public enum StatusVeiculo {
    Disponivel, Alugado, Manutencao
}
